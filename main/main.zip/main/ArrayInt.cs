using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

// Created by Katie Sullivan 4/7/23
// with modifications by Tina Majchrzak
// Data Structures

namespace ArrayIntDriver;

class ArrayInt
{
    #region Fields
    private int?[] _intArray; // Nullable int so that an empty value is not 0
    private int _lastIndex; // Holds the largest index in the array
    private int _size; // Holds the size of the array
    #endregion


    #region Constructors
    public ArrayInt()
    {
        _intArray = new int?[10];
        _lastIndex = -1;
        _size = 10;
    }

    public ArrayInt(int size)
    {
        _intArray = new int?[size];
        _lastIndex = -1;
        _size = size;
    }
    #endregion


    #region Basic Lab Specification
    public int GetSize()
    {
        // Return the size of the array
        return _size;
    }

    public void Resize(int size)
    {
        if (size <= _size)
        {
            Console.WriteLine("Attempted Resize value is less than or equal to current size.");
        }
        else
        {
            int?[] temp = new int?[size];
            Array.Copy(_intArray, temp, _intArray.Length);
            _intArray = temp;
            _size = size;
        }
    }

    public void Append(int value)
    {
        if (_lastIndex >= _size)
        {
            Resize(_size * 2);
            for (int i = 0; i < _intArray.Length - 1; i++)
            {
                if(i == _lastIndex + 1)
                    _intArray[i] = value;
            }
        }
        else
        {
            for (int i = 0; i < _intArray.Length - 1; i++)
            {
                if (i == _lastIndex + 1)
                    _intArray[i] = value;
            }
        }
        _lastIndex++;
    }

    public int GetLast()
    {
        return 7;
    }

    public void DeleteLast()
    {
    }

    public string ListElements()
    {
        return "dummy string";
    }

    public void InsertAt(int index, int value)
    {
    }

    public int RemoveAt(int index)
    {
        return 7;
    }

    public bool Find(int value)
    {
        bool present = false;

        for (int i = 0; i <= _intArray.Length -1; i++)
            if(value == _intArray[i])
                present = true;
        return present;
    }

    public bool FindRemove(int value)
    {
        return false;
    }

    public int FindLargest()
    {
        return 7;
    }

    public void RemoveLargest()
    {
    }
    #endregion


    #region Advanced Lab Specification
    public int GetAt(int index)
    {
        return 7;
    }

    public void SetAt(int index, int value)
    {
    }
    #endregion


    #region Helper Methods
    private int FindReturnIndex(int value)
    {
        return 7;
    }
    #endregion


    #region Thinking Problem
    public void SolveThink(int[] values, int numValues)
    {
    }
    #endregion
}
